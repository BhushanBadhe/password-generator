import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModsRoutingModule } from './mods-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ModsRoutingModule
  ]
})
export class ModsModule { }
